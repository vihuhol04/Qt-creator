#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtCore/qmath.h>
#include <QtMath>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui -> label_error -> setText("");
    ui -> label_result -> setText("");
    ui -> radioButton_add -> setChecked(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_start_clicked()
{
    QString value_1t = ui -> lineEdit_value1 -> text();
    QString value_2t = ui -> lineEdit_2_value2 -> text();
    QString result_text;

    bool c1 = false;
    bool c2 = false;

    double value_1 = value_1t.toDouble(&c1);
    double value_2 = value_2t.toDouble(&c2);
    double result;


    if (ui -> radioButton_add -> isChecked())
    {
        ui -> label_value1 -> setText("1 слагаемое");
        ui -> label_value2 -> setText("2 слагаемое");
        ui -> label_operation -> setText("Сумма:");
        if (c1 and c2)
        {
           ui -> label_error -> setText("");
           result = value_1 + value_2;
           result_text.setNum(result);
           ui -> label_result -> setText(result_text);
        }
        else
        {
            ui -> label_error -> setText("Ошибка в операндах");
        }
    }

    else if (ui -> radioButton_div -> isChecked())
    {
        ui -> label_value1 -> setText("Делимое");
        ui -> label_value2 -> setText("Делитель");
        ui -> label_operation -> setText("Частное:");
        if (c1)
        {
            if (c2)
            {
                if (abs(value_2 - 0.0) < 10e-7)
                {
                    ui -> label_error -> setText("Делить на ноль нельзя");
                    ui -> label_result -> setText("");
                }
                else
                {
                    result = value_1 / value_2;
                    result_text.setNum(result);
                    ui -> label_error -> setText("");
                    ui -> label_result -> setText(result_text);
                }
            }
        }
    }

    else if (ui -> radioButton_minus -> isChecked())
    {
        ui -> label_value1 -> setText("Уменьшаемое");
        ui -> label_value2 -> setText("Вычитаемое");
        ui -> label_operation -> setText("Разность:");
        if (c1 and c2)
        {
            ui -> label_error -> setText("");
            result = value_1 - value_2;
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
        else
        {
            ui -> label_error -> setText("Ошибка в операндах");
        }
    }

    else if (ui -> radioButton_mult -> isChecked())
    {
        ui -> label_value1 -> setText("1 множитель");
        ui -> label_value2 -> setText("2 множитель");
        ui -> label_operation -> setText("Произведение:");
        if (c1 and c2)
        {
            ui->label_error->setText("");
            result = value_1 * value_2;
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
        else {
            ui -> label_error -> setText("Ошибка в операндах");
        }
    }


    else if (ui -> radioButton_step -> isChecked())
    {
        ui -> label_value1 -> setText("Основание");
        ui -> label_value2 -> setText("Показатель степени");
        ui -> label_operation -> setText("Результат:");
        if (c1 and c2)
        {
            ui -> label_error -> setText("");
            result = qPow(value_1, value_2);
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
        else {
            ui -> label_error -> setText("Ошибка в операндах");
        }
    }

    else if (ui -> radioButton_kor -> isChecked())
    {
        ui -> label_value1 -> setText("Число, из которого нужно вычислить корень");
        ui->label_value2->setVisible(0);
        ui->lineEdit_2_value2->setVisible(0);
        ui -> label_operation -> setText("Результат:");
        if (c1)
        {
            ui -> label_error -> setText("");
            result = qSqrt(value_1);
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
    }

    else if (ui -> radioButton_sin -> isChecked())
    {
        ui->label_value1->setText("Градусная мера");
        ui->label_value2->setVisible(0);
        ui->label_error->setText("");
        ui->lineEdit_2_value2->setVisible(0);
        ui -> label_operation -> setText("Вычисление синуса:");
        if (int(value_1 + 0.9999999999999) % 180 == 0 and int(value_1) != 0)
        {
            ui -> label_result -> setText("0");
        }
        else{
            result = sin(value_1 * M_PI / 180.0);
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
    }

    else if (ui -> radioButton_cos -> isChecked())
    {
        ui->label_value1->setText("Градусная мера");
        ui->label_value2->setVisible(0);
        ui->label_error->setText("");
        ui->lineEdit_2_value2->setVisible(0);
        ui -> label_operation -> setText("Вычисление косинуса");
        if (int(value_1 + 0.9999999999999) % 180 == 1 and int(value_1) != 1)
        {
            ui -> label_result -> setText("0");
        }
        else{
            result = cos(value_1 * M_PI / 180.0);
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
    }

    else if (ui -> radioButton_tan -> isChecked())
    {
        ui->label_value1->setText("Градусная мера");
        ui->label_value2->setVisible(0);
        ui->label_error->setText("");
        ui->lineEdit_2_value2->setVisible(0);
        ui -> label_operation -> setText("Вычисление тангенса:");
        if (int(value_1 + 0.9999999999999) % 90 == 0 and int(value_1) != 0)
        {
            ui -> label_result -> setText("Невозможно посчитать");
        }
        else{
            result = tan(value_1 * M_PI / 180.0);
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
    }

    else if (ui -> radioButton_ctg -> isChecked())
    {
        ui->label_value1->setText("Градусная мера");
        ui->label_value2->setVisible(0);
        ui->label_error->setText("");
        ui->lineEdit_2_value2->setVisible(0);
        ui -> label_operation -> setText("Вычисление котангенса:");
        if (int(value_1 + 0.9999999999999 + 90) % 180 == 0 and int(value_1) == 0)
        {
            ui -> label_result -> setText("Невозможно посчитать");
        }
        else{
            result = 1 / tan(value_1 * M_PI / 180.0);
            result_text.setNum(result);
            ui->label_result->setText(result_text);
        }
    }

    else if (ui -> radioButton_arcsin -> isChecked())
    {
        ui->label_value2->setVisible(0);
        ui->lineEdit_2_value2->setVisible(0);
        result = asin(value_1) * 180 / M_PI;
        result_text.setNum(result);
        if (result_text == "nan")
        {
            ui -> label_error -> setText("Невозможно посчитать");
            ui -> label_result -> setText("");
            ui -> label_operation -> setText("");
        }
        else {
            ui -> label_operation -> setText("Вычисление угла:");
            ui -> label_error -> setText("");
            ui -> label_result -> setText(result_text);
            ui -> label_value1 -> setText("Синус угла");
            //ui -> label_value2 -> setText("Не заполнять");
        }
    }

    else if (ui -> radioButton_arccos -> isChecked())
    {
        ui->label_value2->setVisible(0);
        ui->lineEdit_2_value2->setVisible(0);
        result = acos(value_1) * 180 / M_PI;
        result_text.setNum(result);
        if (result_text == "nan")
        {
            ui -> label_error -> setText("Невозможно посчитать");
            ui -> label_result -> setText("");
            ui -> label_operation -> setText("");
        }
        else {
            ui -> label_operation -> setText("Вычисление угла:");
            ui -> label_error -> setText("");
            ui -> label_result -> setText(result_text);
            ui -> label_value1 -> setText("Косинус угла");
            //ui -> label_value2 -> setText("Не заполнять");
        }
    }
}
