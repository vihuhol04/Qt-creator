#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_spinBox_valueChanged(int arg1);

    void on_tableWidget_itemChanged(QTableWidgetItem *item);

    void on_pushButton_random_clicked();

    void on_pushButton_clear_clicked();

    void on_pushButton_count_clicked();

    void on_pushButton_fast_clicked();

    void on_pushButton_gnome_clicked();

    void on_pushButton_ball_clicked();

    void on_pushButton_comb_clicked();

    void on_pushButton_monkey_clicked();

    void on_pushButton_find_clicked();

    void on_pushButton_delete_clicked();

private:
    Ui::MainWindow *ui;

    void quick_sort(double *array, int size);

    void bubble_sort(double *b, int size);

    void gnome_sort(double *ap, int size);

    void comb_sort(double *p, int size);

    bool sort(double mas[], int size);

    bool monkey_sort(double az[], int size);

    bool check(int size);
};

#endif // MAINWINDOW_H
