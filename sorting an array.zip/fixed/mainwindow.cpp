#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <random>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
//функция проверки вводимых значений
bool MainWindow::check(int size)
{
    bool res=1;
    if(size==0)
    {
        return 0;
    }
    for(int i=0;i<size;i++)
    {
        bool flag=1;
        double num=ui->tableWidget->item(i,0)->text().toDouble(&flag);
        if (qIsNaN(num) or qIsInf(num) == 1 or flag==0)
        {
            ui->tableWidget->item(i,0)->setBackground(Qt::red);
            res=0;
        }
        else
        {
            ui->tableWidget->item(i,0)->setBackground(Qt::green);
        }
    }
    return res;
}

//ввод массива
void MainWindow::on_spinBox_valueChanged(int arg1)
{
    ui -> tableWidget -> setColumnCount(1);
    ui -> tableWidget -> setRowCount(arg1);

    for (int i = 0; i < arg1; i++)
    {
        QTableWidgetItem *item_1 = ui -> tableWidget -> item(i, 0);

        if (item_1 == nullptr)
        {
            item_1 = new QTableWidgetItem;
            ui -> tableWidget -> setItem(i, 0, item_1);
        }
    }

    ui -> label_max -> clear();
    ui -> label_mid  -> clear();
    ui -> label_min -> clear();
    ui -> lineEdit_find -> clear();
    ui -> lineEdit_type -> clear();
    ui -> lineEdit_kolvo -> clear();
    ui -> lineEdit_stroka -> clear();
}

//смена цвета во при ошибке ввода
void MainWindow::on_tableWidget_itemChanged(QTableWidgetItem *item)
{
    if(item -> column() ==  0)
    {
        ui -> label_max -> clear();
        ui -> label_mid -> clear();
        ui -> label_min -> clear();
        ui -> lineEdit_type -> clear();
        ui -> lineEdit_kolvo -> clear();
        ui -> lineEdit_stroka -> clear();
        QString text = item -> text();
        bool flag_a = 1;
        double a = item -> text().toDouble(&flag_a);
        if (text.isEmpty())
        {
            item -> setBackground(Qt::yellow);
        }
        else if (qIsNaN(a) == 1 or qIsInf(a) == 1 or flag_a == 0)
        {
            item -> setBackground(Qt::red);
        }
        else
            item -> setBackground(Qt::green);
    }
}

//задаем массив рандомом
void MainWindow::on_pushButton_random_clicked()
{
    int size = ui -> spinBox -> value();
    for (int i = 0; i < size; i++)
    {
        QString b = QString::number(rand());
        ui -> tableWidget -> item(i, 0) -> setText(b);
    }
}

//кнопка очищения полей
void MainWindow::on_pushButton_clear_clicked()
{
    ui -> label_max -> clear();
    ui -> label_mid  -> clear();
    ui -> label_min -> clear();
    ui -> spinBox -> setValue(0);
    ui -> lineEdit_find -> clear();
    ui -> lineEdit_type-> clear();
    ui -> lineEdit_kolvo -> clear();
    ui -> lineEdit_stroka -> clear();
}

//кнопка расчета минимума, максимума и среднего значения в массиве
void MainWindow::on_pushButton_count_clicked()
{
    int size = ui -> tableWidget -> rowCount();
    double sr = 0, min = 100000, max = 0;
    bool ok = false;
    int error = 0;

    if (check(size))
    {
        for (int i = 0; i < size; i++)
        {
            QTableWidgetItem *temp = ui -> tableWidget -> item(i, 0);
            if (temp != NULL)
            {

                double chislo = temp -> text().toDouble();
                sr += chislo;
                if (min > chislo)
                {
                    min = chislo;
                }
                if (max < chislo)
                {
                    max = chislo;
                }
                ok = true;
            }
            else
            {
                error++;
            }
        }
        sr /= size;
        ui -> label_min -> setText(QString::number(min));
        ui -> label_mid -> setText(QString::number(sr));
        ui -> label_max -> setText(QString::number(max));
    }
    else {
        ui->label_max->clear();
        ui->label_mid->clear();
        ui->label_mid->clear();
        QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
    }
}

//проверка отсортированности массива
bool MainWindow::sort(double mas[], int size)
{
    bool sorted = 1;
    for (int i = 0; i < size - 1; i++)
    {
        if (mas[i] > mas[i + 1])
        {
            sorted = 0;
            break;
        }
    }
    return sorted;
}

//функция быстрой сортировки
void MainWindow::quick_sort(double *array, int size)
{
    //Указатели в начало и в конец массива
    int i = 0;
    int j = size - 1;

    //Центральный элемент массива
    int mid = array[size / 2];

    //Делим массив
    do {
        //Пробегаем элементы, ищем те, которые нужно перекинуть в другую часть
        //В левой части массива пропускаем(оставляем на месте) элементы, которые меньше центрального
        while(array[i] < mid) {
            i++;
        }
        //В правой части пропускаем элементы, которые больше центрального
        while(array[j] > mid) {
            j--;
        }

        //Меняем элементы местами
        if (i <= j) {
            int tmp = array[i];
            array[i] = array[j];
            array[j] = tmp;

            i++;
            j--;
        }
    } while (i <= j);


    //Рекурсивные вызовы, если осталось, что сортировать
    if(j > 0) {
        //"Левый кусок"
        quick_sort(array, j + 1);
    }
    if (i < size) {
        //"Првый кусок"
        quick_sort(&array[i], size - i);
    }
}

//кнопка быстрой сортировки
void MainWindow::on_pushButton_fast_clicked()
{
    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];
    bool ok;

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else
    {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                QTableWidgetItem *b = ui -> tableWidget -> item(i, 0);
                double temp = b -> text().toDouble(&ok);
                if (ok)
                {
                    array[i] = temp;
                }
                else
                {
                    QMessageBox::warning(this, "Ошибка", "Некорректное значение", QMessageBox::Ok);
                }
            }

            if (!sort(array, size) and ok)
            {
                quick_sort(array, size);

                for(int i=0;i<size;i++)
                {
                    ui->tableWidget->setItem(i,0, new QTableWidgetItem(QString::number(array[i])));
                }
            }
            else
            {
                QMessageBox::warning(this, "Ошибка", "Массив уже отсортирован", QMessageBox::Ok);
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }

    delete [] array;
}

//функция сортировки пузырьком
void MainWindow::bubble_sort(double *b, int size)
{
    double temp; //вспомогательная переменная
    if (size <= 0) //если массив пустой

    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
        ui -> label_max -> clear();
        ui -> label_mid  -> clear();
        ui -> label_min -> clear();
    }
    else
    {
        for (int i = 0; i < size; i++) //перебираем все элементы и помещаем их в массив
        {
            b[i] = ui -> tableWidget -> item(i, 0) -> text().toDouble();
        }

        for (int i = 0; i < size - 1; i++)
        {
            for (int j = 0; j < size - (i + 1); j++)
            {
                if (b[j] > b[j + 1]) //перемещаем эелементы между собой
                {
                    temp = b[j];
                    b[j] = b[j + 1];
                    b[j + 1] = temp;
                }
            }
        }
    }
}

//кнопка сортировки пузырьком
void MainWindow::on_pushButton_ball_clicked()
{
    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];
    bool ok;

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else
    {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                QTableWidgetItem *b = ui -> tableWidget -> item(i, 0);
                double temp = b -> text().toDouble(&ok);
                if (ok)
                {
                    array[i] = temp;
                }
                else
                {
                    QMessageBox::warning(this, "Ошибка", "Некорректное значение", QMessageBox::Ok);
                }
            }

            if (!sort(array, size) and ok)
            {
                bubble_sort(array, size);

                for(int i=0;i<size;i++)
                {
                    ui->tableWidget->setItem(i,0, new QTableWidgetItem(QString::number(array[i])));
                }
            }
            else
            {
                QMessageBox::warning(this, "Ошибка", "Массив уже отсортирован", QMessageBox::Ok);
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }

    delete [] array;
}

//функцмя гномьей сортировки
void MainWindow::gnome_sort(double *ap, int size)
{
    int i = 0;
    double temp; //вспомогательная переменная

    while (i < size)
    {
        if ((i == 0) or (ap[i - 1] <= ap[i])) {i++;}
        else
        {
            temp = ap[i];
            ap[i] = ap[i - 1];
            ap[i - 1] = temp;
            i--;
        }
    }
}

//кнопка гномьей сортировки
void MainWindow::on_pushButton_gnome_clicked()
{
    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];
    bool ok;

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else
    {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                QTableWidgetItem *b = ui -> tableWidget -> item(i, 0);
                double temp = b -> text().toDouble(&ok);
                if (ok)
                {
                    array[i] = temp;
                }
                else
                {
                    QMessageBox::warning(this, "Ошибка", "Некорректное значение", QMessageBox::Ok);
                }
            }

            if (!sort(array, size) and ok)
            {
                gnome_sort(array, size);

                for(int i=0;i<size;i++)
                {
                    ui->tableWidget->setItem(i,0, new QTableWidgetItem(QString::number(array[i])));
                }
            }
            else
            {
                QMessageBox::warning(this, "Ошибка", "Массив уже отсортирован", QMessageBox::Ok);
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }

    delete [] array;
}

//функция сортировки расческой
void MainWindow::comb_sort(double *p, int size)
{
    bool flag = true;
    double dob = size, n, temp;
    n = dob;

    while (dob > 1 or flag)
    {
        if (dob > 1) {dob /= 1.247;}

        flag = 0;
        int i = 0;
        while (i + dob < n)
        {
            int r = i + (int)dob;
            if (p[i] > p[r])
            {
                temp = p[i];
                p[i] = p[r];
                p[r] = temp;
                flag = 1;
            }
            i++;
        }
    }
}

//кнопка сортировки расческой
void MainWindow::on_pushButton_comb_clicked()
{
    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];
    bool ok;

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else
    {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                QTableWidgetItem *b = ui -> tableWidget -> item(i, 0);
                double temp = b -> text().toDouble(&ok);
                if (ok)
                {
                    array[i] = temp;
                }
                else
                {
                    QMessageBox::warning(this, "Ошибка", "Некорректное значение", QMessageBox::Ok);
                }
            }

            if (!sort(array, size) and ok)
            {
                comb_sort(array, size);

                for(int i=0;i<size;i++)
                {
                    ui->tableWidget->setItem(i,0, new QTableWidgetItem(QString::number(array[i])));
                }
            }
            else
            {
                QMessageBox::warning(this, "Ошибка", "Массив уже отсортирован", QMessageBox::Ok);
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }

    delete [] array;
}

//функция обезьяньей сортировки
bool MainWindow::monkey_sort(double az[], int size)
{
    bool sorted = 0; int count = 0;

    while (!sorted)
    {
        for (int i = 0; i < size; i++)
        {
            int j = qrand() % size;
            if (i != j)
            {
                double op = az[i];
                az[i] = az[j];
                count++;
                if (count == 1001) {return 0;}
            }
        }
    }
    return 1;
}
//кнопка обезьяньей сортировки
void MainWindow::on_pushButton_monkey_clicked()
{
    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];
    bool ok;

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else if (size > 10)
    {
        QMessageBox::warning(this, "Ошибка", "Длина массива не должна превышать 10", QMessageBox::Ok);
    }
    else
    {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                QTableWidgetItem *b = ui -> tableWidget -> item(i, 0);
                double temp = b -> text().toDouble(&ok);
                if (ok)
                {
                    array[i] = temp;
                }
                else
                {
                    QMessageBox::warning(this, "Ошибка", "Некорректное значение", QMessageBox::Ok);
                }
            }

            if (!sort(array, size) and ok)
            {
                monkey_sort(array, size);

                for (int i = 0; i < size; i++)
                {
                    ui->tableWidget->setItem(i,0, new QTableWidgetItem(QString::number(array[i])));
                }
            }
            else
            {
                QMessageBox::warning(this, "Ошибка", "Массив уже отсортирован", QMessageBox::Ok);
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }

    delete [] array;
}

//кнопка поиска элементов
void MainWindow::on_pushButton_find_clicked()
{
    bool flag = true, ok;
    int oshibka=0, kolvo=0;
    QString stroka;

    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else
    {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                array[i] = ui -> tableWidget -> item(i, 0) -> text().toDouble();
            }

            double chislo = ui->lineEdit_find->text().toDouble(&ok);
            if(ok)
            {
                if (!sort(array, size))
                {
                    for (int i = 0; i < size; i++)
                    {
                        if (array[i] == chislo)
                        {
                            kolvo++;
                            stroka += QString::number(i + 1) + ",";
                        }
                    }
                    if (kolvo == 0)
                    {
                        ui -> lineEdit_type-> clear();
                        ui -> lineEdit_kolvo -> clear();
                        ui -> lineEdit_stroka -> clear();
                        QMessageBox::warning(this, "Ошибка", "Число не найдено", QMessageBox::Ok);
                    }
                    else
                    {
                        ui -> lineEdit_type -> setText("Линейный");
                        ui -> lineEdit_stroka -> setText(stroka.remove(stroka.length()-1,1));
                        ui -> lineEdit_kolvo -> setText(QString::number(kolvo));
                    }
                }
                else
                {
                    int left = -1, left_2 = -1;
                    int right = size, right_2 = size;
                    int sred;
                    while((right - left) > 1)
                    {
                        sred = (right + left) / 2;
                        if(array[sred] < chislo)
                        {
                            left = sred;
                        }
                        else
                        {
                            right = sred;
                        }
                    }
                    while ((right_2 - left_2) > 1)
                    {
                        sred = (right_2 + left_2) / 2;
                        if(array[sred] <= chislo)
                        {
                            left_2 = sred;
                        }
                        else
                        {
                            right_2 = sred;
                        }
                    }
                    if (left == left_2 and right == right_2)
                    {
                        QMessageBox::warning(this, "Ошибка", "Число не найдено", QMessageBox::Ok);
                        ui -> lineEdit_type-> clear();
                        ui -> lineEdit_kolvo -> clear();
                        ui -> lineEdit_stroka -> clear();
                    }
                    else if(right==left_2)
                    {
                        ui -> lineEdit_kolvo -> setText("1");
                        ui -> lineEdit_stroka -> setText(QString::number(right + 1));
                        ui -> lineEdit_type -> setText("Бинарный");
                    }
                    else
                    {
                        ui -> lineEdit_kolvo -> setText(QString::number(left_2 - right+1));
                        for (int i = 0; right + i <= left_2; i++)
                        {
                            stroka += QString::number(right+i+1) + ",";
                        }
                        ui -> lineEdit_stroka -> setText(stroka.remove(stroka.length()-1,1));
                        ui -> lineEdit_type -> setText("Бинарный");
                    }
                }
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }
    delete [] array;
}

//кнопка удаления дубликатов
void MainWindow::on_pushButton_delete_clicked()
{
    int size = ui -> spinBox -> value();
    double *array = nullptr;
    array = new double[size];

    if (size <= 0)
    {
        QMessageBox::warning(this, "Ошибка", "Массив не может быть пустым", QMessageBox::Ok);
    }
    else {
        if (check(size))
        {
            for (int i = 0; i < size; i++)
            {
                array[i] = ui -> tableWidget -> item(i, 0) -> text().toDouble();
            }
            int ind = 0, kolvo = 0, tmp = 0;

            if(sort(array, size))
            {
                for(int i = 0; i < size; i++)
                {
                    ind = 0, kolvo = 0;
                    for (int j = i + 1; array[i] == array[j] and j < size; j++)
                    {
                        ind = j;
                        kolvo++;
                    }
                    for(int b = ind + 1; b < size; b++)
                    {
                        array[b - kolvo] = array[b];
                    }
                }
                for (int i = 0; i < size - 1; i++)
                {
                    if(array[i] >= array[i + 1])
                    {
                        tmp = i + 1;
                        break;
                    }
                }
                if(tmp != 0)
                {
                    ui -> tableWidget -> setRowCount(tmp);
                    for (int i = 0; i < tmp; i++)
                    {
                        ui -> tableWidget -> setItem(i, 0, new QTableWidgetItem(QString::number(array[i])));
                    }
                }
                else if (tmp == 0)
                {
                    QMessageBox::warning(this, "Ошибка", "Дубликаты не найдены", QMessageBox::Ok);
                }
            }
            else
            {
                QMessageBox::warning(this, "Ошибка", "Массив не отсортирован", QMessageBox::Ok);
            }
        }
        else
        {
            ui->label_max->clear();
            ui->label_mid->clear();
            ui->label_mid->clear();
            QMessageBox::warning(this, "Ошибка", "Данные неккорректны", QMessageBox::Ok);
        }
    }

    delete [] array;
}
