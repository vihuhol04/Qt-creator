#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui -> lineEdit_ostatok -> setReadOnly(true);
}

MainWindow::~MainWindow()
{
    delete ui;
    ui -> lineEdit_ostatok -> setText("20");
}

void MainWindow::on_pushButton_create_clicked()
{
    QString name = (ui -> lineEdit_name -> text());
    //int power, brain, luck, lovk;
    bool flag = true;

    //Проверка длины имени
    if (flag){
        if ((name.length() < 3) || (name.length() > 20))
        {
            QMessageBox::warning(this, "Ошибка", "Длина имени должна быть от 3 до 20 символов", QMessageBox::Ok);
            flag = false;
            ui -> lineEdit_name -> clear();
        }
    }

    //Проверка выбора пола
    if (flag){
        if (ui -> radioButton_male -> isChecked()){
            flag = true;
        }
        else if (ui -> radioButton_female -> isChecked()){
            flag = true;
        }
        else {
            flag = false;
            QMessageBox:: warning(this, "Ошибка", "Пожалуйста, выберите пол персонажа", QMessageBox::Ok);
        }
    }


    //Ввод первичных характеристик
    int power = ui -> lineEdit_power -> text().toInt(&flag);
    int lovk = ui -> lineEdit_lovkost -> text().toInt(&flag);
    int iq = ui -> lineEdit_brain -> text().toInt(&flag);
    int luck = ui -> lineEdit_luck -> text().toInt(&flag);

    if (flag){
        if (power == 0 || lovk == 0 || iq == 0 || luck == 0){
            QMessageBox::warning(this, "Ошибка", "Пожалуйста, распределите на каждую характеристику хотя бы по единице очков");
            flag = false;
        }
    }

    //Ограничение интеллекта у мужчин
    if (flag){
        if (ui -> radioButton_male -> isChecked()){
            if (iq > 7){
                flag = false;
                QMessageBox::warning(this, "Ошибка", "Значение интеллекта у мужчин не может превышать 7", QMessageBox::Ok);
                ui -> label_health -> setText("");
                ui -> label_mana -> setText("");
                ui -> label_attack -> setText("");
                ui -> label_defence -> setText("");
            }
        }
    }

    //Ограничение силы у женщин
    if (flag){
        if (ui -> radioButton_female -> isChecked()){
            if (power > 7){
                flag = false;
                QMessageBox::warning(this, "Ошибка", "Значение силы для женщин не может превышать 7", QMessageBox::Ok);
                ui -> label_health -> clear();
                ui -> label_mana -> clear();
                ui -> label_attack -> clear();
                ui -> label_defence -> clear();
                ui -> label_hello -> clear();
                ui -> label_class -> clear();
            }
        }
    }

    if (flag)
    {
        int check = power + lovk + iq + luck;
        if (check != 20)
        {
            QMessageBox::warning(this, "Ошибка", "Вы должны распределить все очки", QMessageBox::Ok);
            ui -> label_health -> clear();
            ui -> label_mana -> clear();
            ui -> label_attack -> clear();
            ui -> label_defence -> clear();
            flag = false;
        }
    }

    if (flag) {
        int health, attack, def, mana;
        QString health_text, attack_text, def_text, mana_text;

        health = 4*power + 2*lovk + iq + luck;
        mana = 3*power + lovk + 4*iq + luck;
        attack = 5*power + 3*lovk + iq + 2*luck;
        def = power + 3*lovk + 4*iq + 2*luck;

        ui -> label_health -> setText(health_text.setNum(health));
        ui -> label_mana -> setText(mana_text.setNum(mana));
        ui -> label_attack -> setText(attack_text.setNum(attack));
        ui -> label_defence -> setText(def_text.setNum(def));

    }

    //Классы персонажей, мужчины
    if (flag){
        if (ui -> radioButton_male -> isChecked())
        {
            if ((luck >= 1) and (luck <= 6))
            {
                if ((iq >= 1) and (iq <= 7))
                {
                    ui -> label_class -> setText("Потрошитель");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    if ((lovk >= 1) and (lovk <= 4)){
                        ui -> label_class -> setText("Лучник");
                    }
                    else if ((lovk >= 5) and (lovk <= 10)) {
                        ui -> label_class -> setText("Палач");
                    }
                }
            }
            else if ((luck >= 7) and (luck <= 10)) {
                if ((iq >= 1) and (iq <= 7)){
                    ui -> label_class -> setText("Пророк");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    ui -> label_class -> setText("Колдун");
                }
            }
        }

        //Классы персонажей, женщины
        else if (ui -> radioButton_female -> isChecked())
        {
            if ((luck >= 1) and (luck <= 6))
            {
                if ((iq >= 1) and (iq <= 7))
                {
                    ui -> label_class -> setText("Убийца");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    if ((lovk >= 1) and (lovk <= 4)){
                        ui -> label_class -> setText("Судья");
                    }
                    else if ((lovk >= 5) and (lovk <= 10)) {
                        ui -> label_class -> setText("Валькирия");
                    }
                }
            }
            else if ((luck >= 7) and (luck <= 10)) {
                if ((iq >= 1) and (iq <= 7)){
                    ui -> label_class -> setText("Усмирительница");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    ui -> label_class -> setText("Ведьма");
                }
            }
        }
        else {
            QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите пол персонажа");
            flag = false;
        }
    }

    //Приветствие игрока
    if (flag){
        if (ui -> radioButton_male -> isChecked()){
            ui -> label_hello -> setText("Привет, " + name + "! Ты успешно создал своего персонажа, приятной игры");
        }
        else if (ui -> radioButton_female -> isChecked()) {
            ui -> label_hello -> setText("Привет, " + name + "! Ты успешно создала своего персонажа, приятной игры");
        }
    }
}

//Счетчик
void MainWindow::score()
{
    int power, brain, luck, lovk;
    power = ui -> lineEdit_power -> text().toInt();
    brain = ui -> lineEdit_brain -> text().toInt();
    luck = ui -> lineEdit_luck -> text().toInt();
    lovk = ui -> lineEdit_lovkost -> text().toInt();

    int score_left = 20 - power - brain - luck - lovk;
    QPalette pal;
    if (score_left != 0){
        pal.setColor(QPalette::Text, Qt::red);
    }
    else {
        pal.setColor(QPalette::Text, Qt::green);
    }
    ui -> lineEdit_ostatok -> setPalette(pal);
    ui -> lineEdit_ostatok -> setText(QString::number(score_left));
}


//Очищение полей
void MainWindow::on_pushButton_clear_clicked()
{
    ui -> lineEdit_luck -> clear();
    ui -> lineEdit_name -> clear();
    ui -> lineEdit_brain -> clear();
    ui -> lineEdit_power -> clear();
    ui -> lineEdit_lovkost -> clear();
    ui -> lineEdit_ostatok -> clear();
    ui -> label_mana -> clear();
    ui -> label_attack -> clear();
    ui -> label_defence -> clear();
    ui -> label_class -> clear();
    ui -> label_health -> clear();
    ui -> label_hello -> clear();

    //Очищение полей с ошибками
    ui -> label_error_luck -> clear();
    ui -> label_error_brain -> clear();
    ui -> label_error_power -> clear();
    ui -> label_error_lovkost -> clear();

    //Очищение выбора мужского пола
    ui -> radioButton_male -> setAutoExclusive(false);
    ui -> radioButton_male -> setChecked(false);
    ui -> radioButton_male -> setAutoExclusive(true);

    //Очищение выбора женского пола
    ui -> radioButton_female -> setAutoExclusive(false);
    ui -> radioButton_female -> setChecked(false);
    ui -> radioButton_female -> setAutoExclusive(true);
}

//Измение цвета и значения силы
void MainWindow::on_lineEdit_power_textChanged(const QString &arg1)
{
    int val = ui -> lineEdit_power -> text().toInt();
    QPalette pal, palette;

    if ((val >= 1) and (val <= 3)){
        palette.setColor(QPalette::WindowText, Qt::red);
         ui -> label_error_power -> setText("");
    }
    else if ((val >= 4) and (val <= 6)) {
        palette.setColor(QPalette::WindowText, Qt::yellow);
         ui -> label_error_power -> setText("");
    }
    else if ((val >= 7) and (val <= 10)) {
        palette.setColor(QPalette::WindowText, Qt::green);
        ui -> label_error_power -> setText("");
    }
    else if((val <= 0) || (val > 10))
    {
        ui -> label_error_power -> setText("Введите значение от 1 до 10");
    }
    else {
        palette.setColor(QPalette::WindowText, Qt::black);
         ui -> label_error_power -> setText("");
    }

    ui -> lineEdit_power -> setPalette(pal);
    ui -> label_power -> setPalette(palette);
    score();
}

//Изменение цвета и значения ловкости
void MainWindow::on_lineEdit_lovkost_textChanged(const QString &arg1)
{
    int val = ui -> lineEdit_lovkost -> text().toInt();
    QPalette pal, palette;

    if ((val >= 1) and (val <= 3)){
        palette.setColor(QPalette::WindowText, Qt::red);
        ui -> label_error_lovkost -> setText("");
    }
    else if ((val >= 4) and (val <= 6)) {
        palette.setColor(QPalette::WindowText, Qt::yellow);
        ui -> label_error_lovkost -> setText("");
    }
    else if ((val >= 7) and (val <= 10)) {
        palette.setColor(QPalette::WindowText, Qt::green);
        ui -> label_error_lovkost -> setText("");
    }
    else if((val < 0) || (val > 10))
    {
        ui -> label_error_lovkost -> setText("Введите значение от 1 до 10");
    }
    else {
        palette.setColor(QPalette::WindowText, Qt::black);
        ui -> label_error_lovkost -> setText("");
    }

    ui -> lineEdit_lovkost -> setPalette(pal);
    ui -> label_lovkost -> setPalette(palette);
    score();
}

//Изменение цвета и значения интеллекта
void MainWindow::on_lineEdit_brain_textChanged(const QString &arg1)
{
    int val = ui -> lineEdit_brain -> text().toInt();
    QPalette pal, palette;

    if ((val >= 1) and (val <= 3)){
        palette.setColor(QPalette::WindowText, Qt::red);
        ui -> label_error_brain -> setText("");
    }
    else if ((val >= 4) and (val <= 6)) {
        palette.setColor(QPalette::WindowText, Qt::yellow);
        ui -> label_error_brain -> setText("");
    }
    else if ((val >= 7) and (val <= 10)) {
        palette.setColor(QPalette::WindowText, Qt::green);
        ui -> label_error_brain -> setText("");
    }
    else if((val < 0) || (val > 10))
    {
        ui -> label_error_brain -> setText("Введите значение от 1 до 10");
    }
    else {
        palette.setColor(QPalette::WindowText, Qt::black);
        ui -> label_error_brain -> setText("");
    }

    ui -> lineEdit_brain -> setPalette(pal);
    ui -> label_brain -> setPalette(palette);
    score();
}

//Изменение цвета и значения удачи
void MainWindow::on_lineEdit_luck_textChanged(const QString &arg1)
{
    int val = ui -> lineEdit_luck -> text().toInt();
    QPalette pal, palette;

    if ((val >= 1) and (val <= 3)){
        palette.setColor(QPalette::WindowText, Qt::red);
        ui -> label_error_luck -> setText("");
    }
    else if ((val >= 4) and (val <= 6)) {
        palette.setColor(QPalette::WindowText, Qt::yellow);
        ui -> label_error_luck -> setText("");
    }
    else if ((val >= 7) and (val <= 10)) {
        palette.setColor(QPalette::WindowText, Qt::green);
        ui -> label_error_luck -> setText("");
    }
    else if((val < 0) || (val > 10))
    {
        ui -> label_error_luck -> setText("Введите значение от 1 до 10");
    }
    else {
        palette.setColor(QPalette::WindowText, Qt::black);
        ui -> label_error_luck -> setText("");
    }

    ui -> lineEdit_luck -> setPalette(pal);
    ui -> label_luck -> setPalette(palette);
    score();
}

void MainWindow::on_radioButton_female_clicked(bool checked)
{
    bool flag = true;
    //Ввод первичных характеристик
    int power = ui -> lineEdit_power -> text().toInt(&flag);
    int lovk = ui -> lineEdit_lovkost -> text().toInt(&flag);
    int iq = ui -> lineEdit_brain -> text().toInt(&flag);
    int luck = ui -> lineEdit_luck -> text().toInt(&flag);

    //Ограничение силы у женщин
    if (flag){
        if (ui -> radioButton_female -> isChecked()){
            if (power > 7){
                flag = false;
                QMessageBox::warning(this, "Ошибка", "Значение силы для женщин не может превышать 7", QMessageBox::Ok);
                ui -> label_health -> clear();
                ui -> label_mana -> clear();
                ui -> label_attack -> clear();
                ui -> label_defence -> clear();
                ui -> label_hello -> clear();
                ui -> label_class -> clear();
            }
        }
    }

    //Определение класса, женщины
    if (flag){
        if (ui -> radioButton_female -> isChecked())
        {
            if ((luck >= 1) and (luck <= 6))
            {
                if ((iq >= 1) and (iq <= 7))
                {
                    ui -> label_class -> setText("Убийца");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    if ((lovk >= 1) and (lovk <= 4)){
                        ui -> label_class -> setText("Судья");
                    }
                    else if ((lovk >= 5) and (lovk <= 10)) {
                        ui -> label_class -> setText("Валькирия");
                    }
                }
            }
            else if ((luck >= 7) and (luck <= 10)) {
                if ((iq >= 1) and (iq <= 7)){
                    ui -> label_class -> setText("Усмирительница");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    ui -> label_class -> setText("Ведьма");
                }
            }
        }
        else {
            flag = false;
            QMessageBox::warning(this, "Ошибка", "Выберите пол персонажа", QMessageBox::Ok);
        }
    }

    //Приветствие игрока
    QString name = (ui -> lineEdit_name -> text());
    if (flag){
        if (ui -> radioButton_male -> isChecked()){
            ui -> label_hello -> setText("Привет, " + name + "! Ты успешно создал своего персонажа, приятной игры");
        }
        else if (ui -> radioButton_female -> isChecked()) {
            ui -> label_hello -> setText("Привет, " + name + "! Ты успешно создала своего персонажа, приятной игры");
        }
    }
}

void MainWindow::on_radioButton_male_clicked(bool checked)
{
    bool flag = true;
    //Ввод первичных характеристик
    int power = ui -> lineEdit_power -> text().toInt(&flag);
    int lovk = ui -> lineEdit_lovkost -> text().toInt(&flag);
    int iq = ui -> lineEdit_brain -> text().toInt(&flag);
    int luck = ui -> lineEdit_luck -> text().toInt(&flag);

    //Ограничение интеллекта у мужчин
    if (flag){
        if (ui -> radioButton_male -> isChecked()){
            if (iq > 7){
                flag = false;
                QMessageBox::warning(this, "Ошибка", "Значение интеллекта у мужчин не может превышать 7", QMessageBox::Ok);
                ui -> label_health -> clear();
                ui -> label_mana -> clear();
                ui -> label_attack -> clear();
                ui -> label_defence -> clear();
                ui -> label_hello -> clear();
                ui -> label_class -> clear();
            }
        }
    }

    //Классы персонажей, мужчины
    if (flag){
        if (ui -> radioButton_male -> isChecked())
        {
            if ((luck >= 1) and (luck <= 6))
            {
                if ((iq >= 1) and (iq <= 7))
                {
                    ui -> label_class -> setText("Потрошитель");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    if ((lovk >= 1) and (lovk <= 4)){
                        ui -> label_class -> setText("Лучник");
                    }
                    else if ((lovk >= 5) and (lovk <= 10)) {
                        ui -> label_class -> setText("Палач");
                    }
                }
            }
            else if ((luck >= 7) and (luck <= 10)) {
                if ((iq >= 1) and (iq <= 7)){
                    ui -> label_class -> setText("Пророк");
                }
                else if ((iq >= 8) and (iq <= 10)) {
                    ui -> label_class -> setText("Колдун");
                }
            }
        }
        else {
            flag = false;
            QMessageBox::warning(this, "Ошибка", "Выберите пол персонажа", QMessageBox::Ok);
        }
    }
    //Приветствие игрока
    QString name = (ui -> lineEdit_name -> text());
    if (flag){
        if (ui -> radioButton_male -> isChecked()){
            ui -> label_hello -> setText("Привет, " + name + "! Ты успешно создал своего персонажа, приятной игры");
        }
        else if (ui -> radioButton_female -> isChecked()) {
            ui -> label_hello -> setText("Привет, " + name + "! Ты успешно создала своего персонажа, приятной игры");
        }
    }
}
