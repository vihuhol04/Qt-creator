#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots:
    void on_pushButton_create_clicked();

    void on_pushButton_clear_clicked();

    void on_lineEdit_power_textChanged(const QString &arg1);

    void on_lineEdit_lovkost_textChanged(const QString &arg1);

    void on_lineEdit_brain_textChanged(const QString &arg1);

    void on_lineEdit_luck_textChanged(const QString &arg1);

    void on_radioButton_female_clicked(bool checked);

    void on_radioButton_male_clicked(bool checked);

private:
    Ui::MainWindow *ui;
    void score(void);
};

#endif // MAINWINDOW_H
